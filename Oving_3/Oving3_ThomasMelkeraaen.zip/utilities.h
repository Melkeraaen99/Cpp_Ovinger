void randomWithLimits(int lower, int upper, int repeat);

int randomTarget(int lower, int upper);
