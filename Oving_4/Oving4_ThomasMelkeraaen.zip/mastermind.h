#include "string"
#pragma once

int checkCharactersAndPosition();

int checkCharacters();

void playMastermind();
