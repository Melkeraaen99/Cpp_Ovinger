void message();

void inputAndPrintInteger();

int inputInteger();

int inputIntegersAndPrintSum();

bool isOdd(int n);

void printHumanReadableTime(int sec);

int sum_n_numbers();

int sum_n_numbers_not_zero();

double inputDouble();

double nok_to_euro();

void meny();

void multiplicationTable();

double discriminant(double a, double b, double c);

void printRealRoots(double a, double b, double c);

void solveQuadraticEquation();

void pythagoras();

vector<float> calculateBalance(float innskudd, int rente, int year);

void printBalance(vector<int> saldo_Vector);
