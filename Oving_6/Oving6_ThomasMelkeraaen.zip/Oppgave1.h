#pragma once
#include "std_lib_facilities.h"

void toFile();

void fromFileWithCount(string filename);

void fromFile(string filename);

