void testCallByValue();

void testCallByReference();

void testString();